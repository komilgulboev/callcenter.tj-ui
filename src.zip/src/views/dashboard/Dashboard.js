import { useEffect, useRef, useState } from "react";

export default function Dashboard() {
  const wsRef = useRef(null);

  const [queue, setQueue] = useState(null);
  const [agents, setAgents] = useState([]);
  const [calls, setCalls] = useState([]);

  // =======================
  // WEBSOCKET CONNECT
  // =======================
  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      console.warn("No token, WS not started");
      return;
    }

    const ws = new WebSocket(
      `ws://localhost:8080/ws/monitor?token=${token}`
    );

    wsRef.current = ws;

    ws.onopen = () => {
      console.log("🟢 WS connected");
    };

    ws.onerror = (e) => {
      console.error("❌ WS error", e);
    };

    ws.onclose = () => {
      console.log("🔴 WS closed");
    };

    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);

      // =======================
      // SNAPSHOT
      // =======================
      if (msg.type === "snapshot") {
        console.log("📸 SNAPSHOT", msg.data);

        setQueue(msg.data.queue || null);
        setAgents(msg.data.agents || []);
        setCalls(msg.data.calls || []);
        return;
      }

      // =======================
      // AGENT UPDATE
      // =======================
      if (msg.type === "agent_update") {
        setAgents((prev) => {
          const map = new Map(prev.map((a) => [a.exten, a]));
          map.set(msg.data.exten, msg.data);
          return Array.from(map.values());
        });
        return;
      }

      // =======================
      // CALL CREATE / UPDATE
      // =======================
      if (msg.type === "call_create" || msg.type === "call_update") {
        setCalls((prev) => {
          const map = new Map(prev.map((c) => [c.id, c]));
          map.set(msg.data.id, msg.data);
          return Array.from(map.values());
        });
        return;
      }

      // =======================
      // CALL END
      // =======================
      if (msg.type === "call_end") {
        setCalls((prev) =>
          prev.filter((c) => c.id !== msg.data.id)
        );
      }
    };

    return () => {
      ws.close();
    };
  }, []);

  // =======================
  // CALL DURATION TIMER
  // =======================
  useEffect(() => {
    const timer = setInterval(() => {
      setCalls((prev) =>
        prev.map((c) => ({
          ...c,
          duration:
            c.state === "ACTIVE"
              ? Math.floor(Date.now() / 1000 - c.startTime)
              : c.duration || 0,
        }))
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // =======================
  // UI
  // =======================
  return (
    <div style={{ padding: 20 }}>
      <h2>📊 Call Center Dashboard</h2>

      {/* ================= QUEUE ================= */}
      <h3>📞 Queue</h3>
      {queue ? (
        <table border="1" cellPadding="6" cellSpacing="0">
          <tbody>
            <tr>
              <td><b>Name</b></td>
              <td>{queue.name}</td>
            </tr>
            <tr>
              <td><b>Active calls</b></td>
              <td>{queue.calls}</td>
            </tr>
            <tr>
              <td><b>Missed calls</b></td>
              <td>{queue.missed}</td>
            </tr>
          </tbody>
        </table>
      ) : (
        <p>No queue data</p>
      )}

      {/* ================= AGENTS ================= */}
      <h3 style={{ marginTop: 30 }}>👤 Agents</h3>
      <table border="1" cellPadding="6" cellSpacing="0" width="100%">
        <thead>
          <tr>
            <th>Ext</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {agents.length === 0 && (
            <tr>
              <td colSpan="3">No agents</td>
            </tr>
          )}

          {agents.map((a) => (
            <tr key={`agent-${a.exten}`}>
              <td>{a.exten}</td>
              <td>{a.state}</td>
              <td>
                <button disabled>⏸ Pause</button>{" "}
                <button disabled>🎧 Spy</button>{" "}
                <button disabled>❌ Hangup</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ================= CALLS ================= */}
      <h3 style={{ marginTop: 30 }}>📞 Live Calls</h3>
      <table border="1" cellPadding="6" cellSpacing="0" width="100%">
        <thead>
          <tr>
            <th>From</th>
            <th>To</th>
            <th>Status</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {calls.length === 0 && (
            <tr>
              <td colSpan="4">No active calls</td>
            </tr>
          )}

          {calls.map((c) => (
            <tr key={`call-${c.id}`}>
              <td>{c.from}</td>
              <td>{c.to}</td>
              <td>{c.state}</td>
              <td>{c.duration || 0}s</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
