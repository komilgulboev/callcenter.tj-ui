import React, { useEffect, useState } from "react";
import { useMonitorSocket } from "../../hooks/useMonitorSocket";

// =========================
// API helper
// =========================
async function apiAction(path, params) {
  const token = localStorage.getItem("accessToken");
  const qs = new URLSearchParams(params).toString();

  const res = await fetch(`http://localhost:8080${path}?${qs}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "API error");
  }
}

// =========================
// DASHBOARD
// =========================
export default function Dashboard() {
  const { agents, calls, queues } = useMonitorSocket();
  const [, forceTick] = useState(0);

  // ⏱ обновляем таймер раз в секунду
  useEffect(() => {
    const t = setInterval(() => forceTick(v => v + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // 🔍 Логируем calls для отладки
  useEffect(() => {
    if (calls && Object.keys(calls).length > 0) {
      console.log("📞 CALLS from WebSocket:", calls);
      Object.entries(calls).forEach(([id, call]) => {
        console.log(`  - Call ID: ${id}`, call);
      });
    }
  }, [calls]);

  const agentList = Object.values(agents || {});
  const callsMap = calls || {};
  const queueList = Object.values(queues || {});
  const mainQueue = queueList[0]; // 1 tenant = 1 queue

  return (
    <div style={{ padding: 24 }}>

      {/* ========================= */}
      {/* QUEUE SUMMARY */}
      {/* ========================= */}
      <QueueSummary queue={mainQueue} agents={agents} />

      {/* ========================= */}
      {/* QUEUE STATISTICS */}
      {/* ========================= */}
      <h2>📞 Queue Statistics</h2>

      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 16 }}>
        <thead>
          <tr>
            <th style={th}>Queue</th>
            <th style={th}>Agents</th>
            <th style={th}>In Call</th>
            <th style={th}>Waiting</th>
            <th style={th}>SLA</th>
          </tr>
        </thead>

        <tbody>
          {queueList.length === 0 ? (
            <tr>
              <td colSpan={5} style={td}>No queues</td>
            </tr>
          ) : (
            queueList.map(q => (
              <tr key={q.name}>
                <td style={td}>{q.name}</td>
                <td style={td}>{q.agents}</td>
                <td style={td}>{q.inCall}</td>
                <td style={td}>{q.waiting}</td>
                <td style={td}>{(q.sla * 100).toFixed(1)}%</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* ========================= */}
      {/* AGENTS */}
      {/* ========================= */}
      <h2 style={{ marginTop: 40 }}>📊 Agents Monitor</h2>

      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 16 }}>
        <thead>
          <tr>
            <th style={th}>Agent</th>
            <th style={th}>Status</th>
            <th style={th}>Call</th>
            <th style={th}>Actions</th>
          </tr>
        </thead>

        <tbody>
          {agentList.length === 0 ? (
            <tr>
              <td colSpan={4} style={td}>No agents</td>
            </tr>
          ) : (
            agentList.map(a => {
              const call =
                a.callId && callsMap?.[a.callId]
                  ? callsMap[a.callId]
                  : null;

              // 🔥 ЛЕЧИМ ЗАЛИПШИЙ in-call
              let safeStatus = a.status;
              if (a.status === "in-call" && !call) {
                safeStatus = "idle";
              }

              const duration =
                call?.startedAt
                  ? formatDuration(call.startedAt)
                  : "";

              // 🔍 Логируем для отладки
              /*if (a.status === "in-call") {
                console.log(`🔍 Agent ${a.name}:`, {
                  status: a.status,
                  callId: a.callId,
                  callFound: !!call,
                  call: call
                });
              }*/

              return (
                <tr key={a.name}>
                  <td style={td}>{a.name}</td>

                  <td style={td}>
                    <StatusBadge status={safeStatus} />
                  </td>

                  <td style={td}>
                    {call
                      ? `${call.from} → ${call.to} (${duration})`
                      : a.callId 
                        ? `Call ID: ${a.callId} (not in calls map)`
                        : "-"}
                  </td>

                  <td style={td}>
                    <Actions agent={a} call={call} />
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}

// =========================
// QUEUE SUMMARY
// =========================
function QueueSummary({ queue, agents }) {
  if (!queue) return null;

  let paused = 0;
  Object.values(agents || {}).forEach(a => {
    if (a.status === "paused") paused++;
  });

  const total = queue.agents || 0;
  const inCall = queue.inCall || 0;
  const available = Math.max(total - inCall - paused, 0);

  return (
    <div
      style={{
        display: "flex",
        gap: 18,
        alignItems: "center",
        padding: "10px 14px",
        borderRadius: 8,
        marginBottom: 20,
        background: "var(--panel-bg, rgba(0,0,0,0.05))",
        color: "var(--text-color, inherit)",
      }}
    >
      <strong>📞 Queue {queue.name}</strong>
      <span>👥 {total}</span>
      <span style={{ color: "#43a047" }}>🟢 {available}</span>
      <span style={{ color: "#e53935" }}>🔴 {inCall}</span>
      <span style={{ color: "#1976d2" }}>⏸ {paused}</span>

      {queue.waiting > 0 && (
        <span style={{ color: "#fb8c00" }}>
          ⏳ {queue.waiting} waiting
        </span>
      )}
    </div>
  );
}

// =========================
// ACTIONS
// =========================
function Actions({ agent, call }) {
  const isPaused = agent.status === "paused";
  const isInCall = agent.status === "in-call";

  return (
    <>
      {/* PAUSE */}
      <IconButton
        title={isPaused ? "Unpause" : "Pause"}
        onClick={() =>
          apiAction("/api/actions/pause", { agent: agent.name })
        }
      >
        {isPaused ? "🕒" : "⏸"}
      </IconButton>

      {/* ❌ HANGUP */}
      {isInCall && (
        <IconButton
          title="Hangup"
          onClick={async () => {
            console.log("🔍 HANGUP CLICK:");
            console.log("  Agent:", agent.name);
            console.log("  Agent callId:", agent.callId);
            console.log("  Call object:", call);
            console.log("  Call ID from object:", call?.id);
            
            const callIdToUse = call?.id || agent.callId;
            
            if (!callIdToUse) {
              console.error("❌ No callId available!");
              alert("Error: No call ID available");
              return;
            }
            
            console.log("  Using callId:", callIdToUse);
            
            try {
              await apiAction("/api/actions/hangup", { callId: callIdToUse });
              console.log("✅ Hangup successful");
            } catch (err) {
              console.error("❌ Hangup failed:", err);
              alert(`Hangup failed: ${err.message}`);
            }
          }}
        >
          ❌
        </IconButton>
      )}

    </>
  );
}

function IconButton({ children, onClick, title }) {
  return (
    <button
      title={title}
      onClick={onClick}
      style={{
        marginRight: 6,
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontSize: 16,
      }}
    >
      {children}
    </button>
  );
}

// =========================
// HELPERS
// =========================
function formatDuration(startedAt) {
  const sec = Math.floor((Date.now() - new Date(startedAt)) / 1000);
  const mm = String(Math.floor(sec / 60)).padStart(2, "0");
  const ss = String(sec % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

function StatusBadge({ status }) {
  const colors = {
    "in-call": "#e53935",
    ringing: "#fb8c00",
    idle: "#43a047",
    offline: "#757575",
    paused: "#1976d2",
  };

  return (
    <span
      style={{
        padding: "4px 8px",
        borderRadius: 6,
        background: colors[status] || "#9e9e9e",
        color: "#fff",
        fontSize: 12,
        minWidth: 70,
        display: "inline-block",
        textAlign: "center",
        textTransform: "capitalize",
      }}
    >
      {status}
    </span>
  );
}

// =========================
// STYLES
// =========================
const th = { borderBottom: "1px solid #ddd", padding: 8 };
const td = { borderBottom: "1px solid #eee", padding: 8 };