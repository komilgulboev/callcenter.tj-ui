export const logo = [
  '600 120',
  `
<g fill="none" fill-rule="evenodd">

  <!-- HEXAGON -->


  <!-- CC INSIDE HEX (CENTERED) -->
  <text
    x="48"
    y="78"
    text-anchor="middle"
    font-family="Inter, Segoe UI, Arial"
    font-size="60"
    font-weight="800"
    fill="#f6f3f7"
    letter-spacing="2"
  >
    
  </text>

  <!-- COMPANY NAME -->
  <text
    x="120"
    y="70"
    font-family="Inter, Segoe UI, Arial"
    font-size="88"
    font-weight="550"
    fill="#f6f3f7"
  >
    CallCentrix
  </text>

</g>
`,
]
