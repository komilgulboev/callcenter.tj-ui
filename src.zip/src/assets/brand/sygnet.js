export const sygnet = [
  '80 80',
  `
<g fill="none">
  <text
    x="40"
    y="55"
    text-anchor="middle"
    font-family="Inter, Segoe UI, Arial"
    font-size="65"
    font-weight="800"
    fill="#f6f3f7"
  >
    CC
  </text>
</g>
`,
]
